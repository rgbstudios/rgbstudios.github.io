//RGB Studios Banner Set Up Helper Functions

function bannerSubtitle(subtitle) {
  if(subtitle != null) {
    document.getElementById("banner").classList.add("subtitle");
    document.getElementById("banner-subtitle").innerHTML = subtitle;
  }
}