//RGB Studios Footer Set Up Helper Functions

