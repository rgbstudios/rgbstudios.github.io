//RGB Studios Header Set Up Helper Functions

function headerActiveTab(tabName) {
  switch(tabName) {
    case "home":
      document.getElementById("home-tab").classList.add("active");
      break;
    case "new-projects":
      document.getElementById("new-tab").classList.add("active");
      break;
    case "about-us":
      document.getElementById("about-tab").classList.add("active");
      break;
  }
}