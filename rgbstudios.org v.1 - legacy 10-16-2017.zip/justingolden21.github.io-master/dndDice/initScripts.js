/*TODO:
make buttons work
make rolling work

checkbox for changinginitiative changes currently displaying result

bottom area where it displays names (numbers) high to low (option select)
area where it displays currently active characters in small textarea

*/

var numTRs = 0;

window.onload = function() {
	
	document.getElementById("email").onclick = function() {
		window.open("mailto:justingolden21@gmail.com?Subject=Regarding%20Dnd%20Initiative%20Tracker");
	}
	
	document.getElementById("RGBIcon").onclick = function() {
		window.open("../index.html");
	}
	
	makeNewTr(true);
	makeNewTr(true);
	makeNewTr(true);
}

function roll(charNum) {
	var rollResult = random(1,20);
	var initVal = parseInt(document.getElementById("initInput" + charNum).value);
	document.getElementById("rollInput" + charNum).value = rollResult;
	document.getElementById("rollTotalInput" + charNum).value = rollResult + initVal;
}

function deleteUncheckedTRs() {
	for(var i = 0; i < numTRs; i++) {
		if(document.getElementById("doesRollInput" + i) != undefined) {
			if(!document.getElementById("doesRollInput" + i).checked) {
				document.getElementById("deleteButton" + i).click();
			}
		}
	}
}

function deletePlayerTRs() {
	for(var i = 0; i < numTRs; i++) {
		if(document.getElementById("doesRollInput" + i) != undefined) {
			if(document.getElementById("isPlayer" + i).checked) {
				document.getElementById("deleteButton" + i).click();
			}
		}
	}
}

function deleteNPC_TRs() {
	for(var i = 0; i < numTRs; i++) {
		if(document.getElementById("doesRollInput" + i) != undefined) {
			if(!document.getElementById("isPlayer" + i).checked) {
				document.getElementById("deleteButton" + i).click();
			}
		}
	}
}

function deleteAllTRs() {
	for(var i = 0; i < numTRs; i++) {
		if(document.getElementById("doesRollInput" + i) != undefined) {
			document.getElementById("deleteButton" + i).click();
		}
	}
}


function makeNewTr(player) {
	
	var num = numTRs;
	
	var tr = document.createElement("tr");
	tr.className = "characterTr";

	var nameInput = document.createElement("input");
	nameInput.title = "character name";
	nameInput.maxLength = "20";
	nameInput.placeholder = "character name";
	nameInput.type = "text";
	tr.appendChild(nameInput);
	
	var rollP = document.createElement("p");
	rollP.innerHTML = " Roll? ";
	tr.appendChild(rollP);
	
	var doesRollInput = document.createElement("input");
	doesRollInput.type = "checkbox";
	doesRollInput.className = "doesRoll";
	doesRollInput.title = "Roll this character";
	doesRollInput.id = "doesRollInput" + num;
	doesRollInput.disabled = false;
	doesRollInput.checked = true;
	tr.appendChild(doesRollInput);
	
	var playerP = document.createElement("p");
	playerP.innerHTML = " Player? ";
	tr.appendChild(playerP);
	
	var isPlayer = document.createElement("input");
	isPlayer.type = "checkbox";
	isPlayer.id = "isPlayer" +  num;
	isPlayer.title = "Player or NPC";
	isPlayer.checked = player;
	tr.appendChild(isPlayer);
	
	var initP = document.createElement("p");
	initP.innerHTML = " Initiative: ";
	tr.appendChild(initP);

	var initInput = document.createElement("input");
	initInput.type = "number";
	initInput.value = "0";
	initInput.maxLength = "3";
	initInput.id = "initInput" + num;
	initInput.title = "initiative";
	initInput.placeholder = "initiative";
	tr.appendChild(initInput);
	
	//var br = document.createElement("br");
	//tr.appendChild(br);
	
	var rollButton = document.createElement("button");
	rollButton.type = "submit";
	rollButton.className = "rollButton";
	rollButton.title = "Roll d20 for character's initiative";
	rollButton.innerHTML = "Roll";
	
	rollButton.onclick = function() {
		roll(num);
	}
	
	
	tr.appendChild(rollButton);
	
	var rollResultP = document.createElement("p");
	rollResultP.innerHTML = " Initiative Roll: ";
	tr.appendChild(rollResultP);

	var rollInput = document.createElement("input");
	rollInput.type = "number";
	rollInput.id = "rollInput" + num;
	rollInput.disabled = "true";
	rollInput.title = "initiative roll";
	tr.appendChild(rollInput);
	
	var totalResultP = document.createElement("p");
	totalResultP.innerHTML = " Total Result: ";
	tr.appendChild(totalResultP);

	var rollTotalInput = document.createElement("input");
	rollTotalInput.id = "rollTotalInput" + num;
	rollTotalInput.type = "number";
	rollTotalInput.disabled = "true";
	rollTotalInput.title = "initiative total";
	tr.appendChild(rollTotalInput);
		
	var deleteButton = document.createElement("img");
	deleteButton.src = "icon/delete.svg";
	deleteButton.className = "svgButton";
	deleteButton.id = "deleteButton" + num;
	deleteButton.title = "Delete Item";
	deleteButton.onclick = function() {
		this.parentNode.parentNode.removeChild(this.parentNode);
	}
	tr.appendChild(deleteButton);

	document.getElementById("charactersTable").appendChild(tr);
	
	numTRs++;
}
